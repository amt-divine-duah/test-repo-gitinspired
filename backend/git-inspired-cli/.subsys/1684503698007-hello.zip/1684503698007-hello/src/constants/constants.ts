export enum FOLDERNAME {
  NAME = ".subsys",
}
export enum FILENAME {
    CONFIG = '.config'
}
export enum API {
  CONFIG = "http://localhost:3001/api/cli/validate-config",
}
export const configQuestions = [
  {
    type: "input",
    name: "uniqueCode",
    message: "What is the unique code for the assignment? ",
  },
  {
    type: "input",
    name: "studentId",
    message: "What is your student Id",
  },
];
export const submitSpecificSnapshot = (snapshot: string) => {
    console.log("I submit specific snapshot here", snapshot)
}
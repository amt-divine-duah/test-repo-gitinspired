export const ignoreFilesUtils = () => {
    console.log("I have to ignore files")
}